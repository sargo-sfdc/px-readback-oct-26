window.SITE={"groups": [{"name": "Overview", "color": "#14233d", "intro": true, "pages": [[0, "Welcome and agenda"], [1, "Executive summary"]]}, {"name": "Today", "color": "#0f8a77", "intro": false, "pages": [[2, "How PX works"], [3, "HubSpot today"]]}, {"name": "Vision", "color": "#1b6fd6", "intro": false, "pages": [[4, "Architecture"], [5, "Four pillars"], [6, "Slack as the front door"], [7, "One marketing system"], [8, "Monday morning"], [9, "Data model"]]}, {"name": "Proof", "color": "#6b3fd1", "intro": false, "pages": [[10, "Net revenue view"], [11, "Media spend to revenue"], [12, "Onboarding journeys"]]}, {"name": "Value", "color": "#c46a12", "intro": false, "pages": [[13, "Value calculator"], [14, "What you can retire"], [15, "Cost picture"]]}, {"name": "Plan", "color": "#14233d", "intro": false, "pages": [[16, "Path forward"]]}]};
document.addEventListener('DOMContentLoaded',function(){
/* Navigation engine. build_site.py prepends:
   window.SITE = {groups:[{name, color, intro, pages:[[pageIndex, title], ...]}]} */
(function(){
const views=[...document.querySelectorAll('.view')];
const G=window.SITE.groups;
const gOf=i=>G.findIndex(g=>g.pages.some(p=>p[0]===i));
const nameOf=i=>{for(const g of G)for(const p of g.pages)if(p[0]===i)return p[1];return''};
const majors=document.querySelector('.majors'),pages=document.getElementById('pages'),hdr=document.querySelector('.hdr');
let n=0;
G.forEach((g,gi)=>{if(g.intro)return;n++;g.num=n;
 const b=document.createElement('button');b.className='mj';b.dataset.g=gi;b.style.setProperty('--mc',g.color);
 const num=document.createElement('span');num.className='num';num.textContent=n;
 const lbl=document.createElement('span');lbl.className='lbl';lbl.textContent=g.name;
 b.append(num,lbl);b.addEventListener('click',()=>go(g.pages[0][0]));majors.appendChild(b);});
let cur=0;
function go(i){cur=Math.max(0,Math.min(views.length-1,i));
 views.forEach((v,j)=>v.classList.toggle('on',j===cur));views[cur].scrollTop=0;
 const gi=gOf(cur),g=G[gi];hdr.style.setProperty('--acc',g.color);
 majors.querySelectorAll('.mj').forEach(b=>{const k=+b.dataset.g;b.classList.toggle('done',k<gi);
  if(k===gi)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current');});
 document.getElementById('sublabel').textContent=g.intro?'Start here':g.num+'. '+g.name;
 pages.innerHTML='';
 g.pages.forEach(p=>{const t=document.createElement('button');t.className='pg-tab';t.textContent=p[1];
  if(p[0]===cur)t.setAttribute('aria-current','page');t.addEventListener('click',()=>go(p[0]));pages.appendChild(t);});
 const un=document.getElementById('upnext');un.textContent='';
 if(cur<views.length-1){un.append('Up next: ');const b=document.createElement('b');b.textContent=nameOf(cur+1);un.append(b);}
 document.getElementById('count').textContent='Page '+(cur+1)+' of '+views.length;
 document.getElementById('prev').disabled=cur===0;document.getElementById('next').disabled=cur===views.length-1;
 document.getElementById('edgeL').classList.toggle('off',cur===0);
 document.getElementById('edgeR').classList.toggle('off',cur===views.length-1);
 document.getElementById('bar').style.width=((cur+1)/views.length*100)+'%';
 [pages.querySelector('[aria-current]'),majors.querySelector('[aria-current]')].forEach(el=>{
  if(el&&el.scrollIntoView)el.scrollIntoView({block:'nearest',inline:'nearest'})});
 try{history.replaceState(null,'','#'+cur)}catch(e){}}
window.goToPage=go;
/* Any element with data-go="N" jumps to page N (useful for agenda cards on the welcome page). */
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(+b.dataset.go)));
document.getElementById('prev').onclick=()=>go(cur-1);document.getElementById('next').onclick=()=>go(cur+1);
document.getElementById('edgeL').onclick=()=>go(cur-1);document.getElementById('edgeR').onclick=()=>go(cur+1);
document.addEventListener('keydown',e=>{if(/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)||e.shiftKey)return;
 if(e.key==='ArrowRight'||e.key==='PageDown')go(cur+1);if(e.key==='ArrowLeft'||e.key==='PageUp')go(cur-1);});
go(parseInt(location.hash.slice(1))||0);
})();

/* calculator.html */
(function(){

const ids=['rep','bi','rate','sel','adm','rec','ads','shift','gain','waste','cons','pub','act','pnr','stl','anr'];const d={};ids.forEach(i=>d[i]=document.getElementById(i).value);
const $=i=>+document.getElementById(i).value||0;const f=n=>'$'+Math.round(n).toLocaleString();
function calc(){const w=48;const h1=($('rep')+$('bi'))*w;const o1=h1*$('rate');const h2=$('sel')*$('adm')*$('rec')/100*w;const o2=h2*$('rate');
const o3=$('pub')*$('act')/100*$('pnr');const o4=$('stl')*$('anr');const o5=$('ads')*$('shift')/100*$('gain')/100;const o6=$('ads')*$('waste')/100;const o7=$('cons');
document.getElementById('o1').textContent=f(o1);document.getElementById('o2').textContent=f(o2);document.getElementById('o3').textContent=f(o3);document.getElementById('o4').textContent=f(o4);
document.getElementById('o5').textContent=f(o5);document.getElementById('o6').textContent=f(o6);document.getElementById('o7').textContent=f(o7);document.getElementById('total').textContent=f(o1+o2+o3+o4+o5+o6+o7);
document.getElementById('hrs').textContent=Math.round(h1+h2).toLocaleString()+' hours a year given back, which is about '+(Math.round((h1+h2)/1920*10)/10)+' full-time people. This assumes 48 working weeks.';}
ids.forEach(i=>document.getElementById(i).addEventListener('input',calc));
document.getElementById('reset').onclick=()=>{ids.forEach(i=>document.getElementById(i).value=d[i]);calc()};calc();
document.getElementById('calc-print').onclick=()=>window.print();

})();
/* cost_public.html */
(function(){

const ids=['cost-hub','cost-slack','cost-tab','cost-mon','cost-blast','cost-other'];
function tot(){let s=0;ids.forEach(i=>s+=(+document.getElementById(i).value||0));document.getElementById('cost-total').textContent='$'+Math.round(s).toLocaleString();}
ids.forEach(i=>document.getElementById(i).addEventListener('input',tot));tot();
document.getElementById('cost-print').onclick=()=>window.print();

})();
});
